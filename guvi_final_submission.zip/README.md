GUVI Internship - Submission package (SQLite demo)
Run locally with PHP built-in server:
1. unzip
2. open terminal in folder
3. run: php -S 127.0.0.1:8000
4. open http://127.0.0.1:8000/index.html
No external DB required (uses data/users.db created automatically). Include screenshots of register/login for submission.
